//
//  main.hpp
//  testAllegro
//
//  Created by Jose de Jesus Palos on 26/10/22.
//  Copyright © 2022 Jose de Jesus Palos. All rights reserved.
//

#ifndef main_hpp
#define main_hpp

#define ALTO 600
#define ANCHO 800

ALLEGRO_TIMER* timer=NULL;
ALLEGRO_EVENT_QUEUE* queue=NULL;
ALLEGRO_DISPLAY *display = NULL;
ALLEGRO_FONT* font = NULL;

ALLEGRO_EVENT event;

ALLEGRO_BITMAP* uaa;
ALLEGRO_BITMAP* imgPersonaje;
int xPer,yPer;
float vXPer,vYPer;
double dt;

ALLEGRO_BITMAP* imgPersonaje2;
int xPer2,yPer2;
float vXPer2,vYPer2;
double dt2;


int init();
void deinit();
void pintar(int i);
void fisica(float dt,float dt2);

#endif /* main_hpp */
