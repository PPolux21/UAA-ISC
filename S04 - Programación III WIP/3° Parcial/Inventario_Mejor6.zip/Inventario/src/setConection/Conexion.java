/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package setConection;

import java.sql.*;

/**
 *
 * @author luisa
 */
public class Conexion {
    
    /*  BASE DE DATOS EN CONSTRUCCION
        Todavia se deben ajustar los datos que se tienen que utilizar en la tabla y no se sabe si se van a
        agregar más tablas
    */  
    
    //En la siguiente linea debes reemplazar la ubicación de la DB de tu PC
    String strConexionDB="jdbc:sqlite:C:/Users/josel/OneDrive/Documentos/NetBeansProjects/Inventario/data_base/pruebaDB.s3db";
    Connection conn=null;    //clase para hacer la conexion
    
    public Conexion(){
        try{
            Class.forName("org.sqlite.JDBC");   //driver para hacer la conexion
            conn=DriverManager.getConnection(strConexionDB);    //DriverManager manipular
            System.out.println("Conexion establecida");
        }catch(Exception e){
            System.out.println("Error de conexion a la BD"+e);
        }
    }
    
    public int ejecutarSentenciaSQL(String strSentenciaSQL){
        try{
            PreparedStatement pstm = conn.prepareStatement(strSentenciaSQL);
            pstm.execute();
            return 1;
        }catch(SQLException e){ //excepcion de las sentencias SQL
            System.out.println("Error de insercion de los datos "+e);
            return 0;
        }
    }
    
    public ResultSet consultarRegistro(String strSentenciaSQL){
        try{
            PreparedStatement pstm = conn.prepareStatement(strSentenciaSQL);
            ResultSet respuesta = pstm.executeQuery();
            return respuesta;
        }catch(SQLException e){
            System.out.println("Error de Query "+e);
            return null;
        }
    }
    
    /*public static void main(String args[]){
        Conexion conexion = new Conexion();
    }*/

}
