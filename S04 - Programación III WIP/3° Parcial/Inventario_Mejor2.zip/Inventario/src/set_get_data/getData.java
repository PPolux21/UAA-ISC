/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package set_get_data;

/**
 *
 * @author luisa
 */
public interface getData {
    public Data_information recuperarDatos();
}
